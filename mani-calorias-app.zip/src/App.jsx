import CaloriasConManiApp from './CaloriasConManiApp';
export default function App() {
  return <CaloriasConManiApp />;
}